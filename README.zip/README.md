# Piano JS
> `by KHIAL Omar`
## Rendu disponible a cette adresse :
- All browsers except Safari :
[piano-js](https://piano.omarmelade.com)
- Safari compatible with recording not working :
[sad-piano-js](https://omarmelade.com)
## Features :
### With the all features website you can :
- Change wave to make a different sound going out of the piano.
- You can adjust the volume of each track
- You can record your song and listen it after.
- You can see colored balls when you click on a note.
### Features not on safari :
- Recording.